// Vita3K emulator project
// Copyright (C) 2026 Vita3K team
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#pragma once

#include <QString>

#include <span>
#include <string_view>
#include <util/fs.h>

class QApplication;

namespace gui::i18n {

struct UiLanguageOption {
    std::string_view tag;
    std::string_view native_name;
};

std::span<const UiLanguageOption> ui_language_options(const fs::path &static_assets_path);
bool apply_ui_language(QApplication &app, std::string_view configured_tag, const fs::path &static_assets_path);
QString language_name(std::string_view tag);

} // namespace gui::i18n
